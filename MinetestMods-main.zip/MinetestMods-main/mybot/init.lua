minetest.register_tool("mybot:controller", {
    description = "Used for prompting NPCs to follow you.",
    inventory_image = "controller.png",
})
