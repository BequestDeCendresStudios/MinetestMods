-- First Block Test
minetest.register_node("neonbassanova:lime", {

    description  = "Lime Grid",

    tiles = {"lime_grid.png"},

    groups = {oddly_breakable_by_hand = 2},

    sounds = default.node_sound_glass_defaults()
})

minetest.register_node("neonbassanova:red", {

    description  = "Red Grid",

    tiles = {"red_grid.png"},

    groups = {oddly_breakable_by_hand = 2},

    sounds = default.node_sound_glass_defaults()
})

minetest.register_node("neonbassanova:prussian", {

    description  = "Prussian Grid",

    tiles = {"prussian_grid.png"},

    groups = {oddly_breakable_by_hand = 2},

    sounds = default.node_sound_glass_defaults() 
})
