-- First Block Test
minetest.register_node("necrosublimophilia:wall", {

    description  = "Wall",

    tiles = {"wall_verticle.png", "wall_verticle.png", "wall.png", "wall.png", "wall.png", "wall.png"},

    groups = {oddly_breakable_by_hand = 2},

    sounds = default.node_sound_wood_defaults()
})
