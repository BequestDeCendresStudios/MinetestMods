-- Light Dust
minetest.register_decoration({
    deco_type = "simple",
    place_on = {"warmandcoldgrey:eclipse_floor"},
    sidelen = 16,
    fill_ratio = 0.1,
    biomes = {"Light Dust Grassland"},
    y_max = 200,
    y_min = 1,
    decoration = "warmandcoldgrey:grass_1",
})

minetest.register_decoration({
    deco_type = "simple",
    place_on = {"warmandcoldgrey:eclipse_floor"},
    sidelen = 16,
    fill_ratio = 0.1,
    biomes = {"Light Dust Grassland"},
    y_max = 200,
    y_min = 1,
    decoration = "warmandcoldgrey:grass_2",
})

minetest.register_decoration({
    deco_type = "simple",
    place_on = {"warmandcoldgrey:eclipse_floor"},
    sidelen = 16,
    fill_ratio = 0.1,
    biomes = {"Light Dust Grassland"},
    y_max = 200,
    y_min = 1,
    decoration = "warmandcoldgrey:grass_3",
})

minetest.register_decoration({
    deco_type = "simple",
    place_on = {"warmandcoldgrey:eclipse_floor"},
    sidelen = 16,
    fill_ratio = 0.1,
    biomes = {"Light Dust Grassland"},
    y_max = 200,
    y_min = 1,
    decoration = "warmandcoldgrey:grass_4",
})
