xpanes.register_pane("warmandcoldgrey:tobaccopane", {
	description = S("Tobacco Pane"),
	textures = {"tobaccowindow.png", "", "xpanes_edge.png"},
	inventory_image = "tobaccowindow.png",
	wield_image = "tobaccowindow.png",
	sounds = default.node_sound_glass_defaults(),
	groups = {snappy=2, cracky=3, oddly_breakable_by_hand=3},

	recipe = {
		{"default:glass", "default:glass", "default:glass"},
		{"default:glass", "default:glass", "default:glass"}
	}
})

--minetest.register_node("warmandcoldgrey:window", {
--    drawtype = "plantlike",
--
--    tiles = {"tobaccowindow.png", "xpanes_edge.png"},
--
--	paramtype = "light",
--	sunlight_propagates = true,
--	walkable = false,
--	buildable_to = true,
--	groups = {cracky = 3, flora = 1, attached_node = 1, grass = 1,
--		normal_grass = 1, flammable = 1},
--
--	sounds = default.node_sound_glass_defaults(),
--})
