minetest.register_node("warmandcoldgrey:gunmetal_floor", {

    description  = "Gunmetal Floor",

    tiles = {"GunmetalFloor.png"},

    groups = {cracky = 3, level = 3},

    sounds = default.node_sound_glass_defaults()
})

minetest.register_node("warmandcoldgrey:gunmetal_wall", {

    description  = "Gunmetal Wall",

    tiles = {"GunmetalWall.png"},

    groups = {cracky = 3, level = 3},

    sounds = default.node_sound_glass_defaults()
})

minetest.register_node("warmandcoldgrey:eclipse_floor", {

    description  = "Eclipse Floor",

    tiles = {"EclipseFloor.png"},

    groups = {cracky = 3, level = 3},

    sounds = default.node_sound_dirt_defaults()
})

minetest.register_node("warmandcoldgrey:eclipse_wall", {

    description  = "Eclipse Wall",

    tiles = {"EclipseWall.png"},

    groups = {cracky = 3, level = 3},

    sounds = default.node_sound_dirt_defaults()
})


-- Cusine Dojo Blocks
minetest.register_node("warmandcoldgrey:wall", {
    description = "Wall of the dojo.",
    tiles = {"HouseVoid.png", "HouseRoof.png", "HouseWall.png", "HouseWall.png", "HouseWall.png", "HouseWall.png"},
    paramtype2 = "facedir",
    groups = {choppy = 3, level = 3},

    sounds = default.node_sound_wood_defaults()
})

minetest.register_node("warmandcoldgrey:floor", {
    description = "Floor of the dojo.",
    tiles = {"HouseFloor.png", "HouseFloor.png", "HouseFloor.png", "HouseFloor.png", "HouseFloor.png", "HouseFloor.png"},
    --tiles = {"HouseFloorAlternative.png", "HouseFloorAlternative.png", "HouseFloorAlternative.png", "HouseFloorAlternative.png", "HouseFloorAlternative.png", "HouseFloorAlternative.png"},
    paramtype2 = "facedir",
    groups = {choppy = 3, level = 3},

    sounds = default.node_sound_wood_defaults()
})

minetest.register_node("warmandcoldgrey:grass", {
    description = "Tended grass of the dojo.",
    tiles = {"ExteriorGrass.png", "EclipseFloor.png", "EclipseFloor.png", "EclipseFloor.png", "EclipseFloor.png", "EclipseFloor.png"},
    paramtype2 = "facedir",
    groups = {crumbly = 3, level = 3},

    sounds = default.node_sound_wood_defaults()
})

minetest.register_node("warmandcoldgrey:dojobrick", {
    description = "Wall of the dojo.",
    tiles = {"HouseVoid.png", "HouseRoof.png", "HouseBricks.png", "HouseBricks.png", "HouseBricks.png", "HouseBricks.png"},
    paramtype2 = "facedir",
    groups = {choppy = 3, level = 3},

    sounds = default.node_sound_wood_defaults()
})

minetest.register_node("warmandcoldgrey:dojobrick", {
    description = "Wall of the dojo.",
    tiles = {"HouseVoid.png", "HouseRoof.png", "HouseBricks.png", "HouseBricks.png", "HouseBricks.png", "HouseBricks.png"},
    paramtype2 = "facedir",
    groups = {choppy = 3, level = 3},

    sounds = default.node_sound_wood_defaults()
})

-- Tobacco Floral
minetest.register_node("warmandcoldgrey:tobaccodirt", {
    description = "Tobacco colored dirt.",
    tiles = {"tobaccoblackflowers3.png", "tobaccoblack.png", "tobaccoblack.png", "tobaccoblack.png", "tobaccoblack.png", "tobaccoblack.png"},
    paramtype2 = "facedir",
    groups = {crumbly = 3, level = 3},

    sounds = default.node_sound_dirt_defaults()
})


-- Decorations
minetest.register_node("warmandcoldgrey:grass_1", {
    drawtype = "plantlike",

    description  = "Yumemoire Grass 1",
    --tiles = {"beds_transparent.png", "beds_transparent.png", "yume_grass_1.png", "yume_grass_1.png", "yume_grass_1.png", "yume_grass_1.png"},

    tiles = {"yume_grass_1.png"},

	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, grass = 1,
		normal_grass = 1, flammable = 1},

	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("warmandcoldgrey:grass_2", {
    drawtype = "plantlike",

    tiles = {"yume_grass_2.png"},

	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, grass = 1,
		normal_grass = 1, flammable = 1},

	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("warmandcoldgrey:grass_3", {
    drawtype = "plantlike",

    description  = "Yumemoire Grass 3",
    --tiles = {"beds_transparent.png", "beds_transparent.png", "yume_grass_3.png", "yume_grass_3.png", "yume_grass_3.png", "yume_grass_3.png"},
    tiles = {"yume_grass_3.png"},

	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, grass = 1,
		normal_grass = 1, flammable = 1},

	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("warmandcoldgrey:grass_4", {
    drawtype = "plantlike",

    description  = "Yumemoire Grass 4",
    --tiles = {"beds_transparent.png", "beds_transparent.png", "yume_grass_4.png", "yume_grass_4.png", "yume_grass_4.png", "yume_grass_4.png"},
    tiles = {"yume_grass_4.png"},

	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, grass = 1,
		normal_grass = 1, flammable = 1},

	sounds = default.node_sound_leaves_defaults(),
})
