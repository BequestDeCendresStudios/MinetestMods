local modpath = minetest.get_modpath("warmandcoldgrey") .. DIR_DELIM

-- Required FIles
dofile(modpath .. "blocks.lua")
dofile(modpath .. "biomes.lua")
dofile(modpath .. "decotypes.lua")
