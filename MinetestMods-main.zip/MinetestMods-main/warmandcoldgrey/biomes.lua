--name = "tundra",
--heat_point = 0,
--humidity_point = 0,
--
--name = "taiga",
--heat_point = 0,
--humidity_point = 100,
--
--name = "grassland",
--heat_point = 35,
--humidity_point = 0,
--
--name = "coniferous_forest",
--heat_point = 35,
--humidity_point = 100,
--
--name = "sandstone_grassland",
--heat_point = 65,
--humidity_point = 0,
--
--name = "deciduous_forest",
--heat_point = 65,
--humidity_point = 100,
--
--name = "desert",
--heat_point = 100,
--humidity_point = 0,
--
--name = "rainforest",
--heat_point = 100,
--humidity_point = 100,

-- Section 1
minetest.register_biome({
    name = "Eclipse Biome Tundra",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 2,
    humidity = 2,
})

minetest.register_biome({
    name = "Eclipse Biome Taiga",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 2,
    humidity = 98,
})

minetest.register_biome({
    name = "Eclipse Biome Coniferous Forest",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 37,
    humidity = 98,
})

minetest.register_biome({
    name = "Eclipse Biome Sandstone Grassland",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 67,
    humidity = 2,
})

minetest.register_biome({
    name = "Eclipse Biome Deciduous Forest",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 67,
    humidity = 98,
})

minetest.register_biome({
    name = "Eclipse Biome Desert",

    node_top = "warmandcoldgrey:eclipse_floor 2",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 98,
    humidity = 3,
})

minetest.register_biome({
    name = "Eclipse Biome Rainforest",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 98,
    humidity = 98,
})

-- Section 2
minetest.register_biome({
    name = "Eclipse Biome Desert 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 99,
    humidity = 2,
})

-- Section 2
minetest.register_biome({
    name = "Eclipse Biome Tundra 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 2,
    humidity = 2,
})

minetest.register_biome({
    name = "Eclipse Biome Taiga 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 2,
    humidity = 99,
})

minetest.register_biome({
    name = "Eclipse Biome Coniferous Forest 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 37,
    humidity = 99,
})

minetest.register_biome({
    name = "Eclipse Biome Sandstone Grassland 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 67,
    humidity = 2,
})

minetest.register_biome({
    name = "Eclipse Biome Deciduous Forest 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 67,
    humidity = 99,
})

minetest.register_biome({
    name = "Eclipse Biome Desert",

    node_top = "warmandcoldgrey:eclipse_floor 2",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 99,
    humidity = 2,
})

minetest.register_biome({
    name = "Eclipse Biome Rainforest 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 99,
    humidity = 99,
})

-- Section 2
minetest.register_biome({
    name = "Eclipse Biome Desert 2",

    node_top = "warmandcoldgrey:eclipse_floor",
    depth_top = 6,
    node_filler = "default:gravel",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -200,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 99,
    humidity = 2,
})
