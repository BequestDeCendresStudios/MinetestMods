-- Damage Blocks
local time1 = 0
local time2 = 0

-- Healing Stations
local time3 = 0

-- Allows corrupted blocks to damage the player. Eventually implementing corruption resisting boots.
minetest.register_globalstep(function(dtime)
    time1 = time1 + dtime

	-- every 1 second
	if time1 > 1 then

		-- reset time for next check
		time1 = 0

		-- check players
		for _,player in ipairs(minetest.get_connected_players()) do
			
			-- where am I?
			local pos = player:getpos()
				
			-- am I near a block of uranium?
			local near = minetest.find_node_near(pos, 1, "corruptionlands:infected")

			if near then
					
				-- am I touching the uranium? if so it hurts
				for _,object in ipairs(minetest.get_objects_inside_radius(near, 1.0)) do
                    object:set_hp(object:get_hp()-1)
				end

			end

		end
		
	end
end)

minetest.register_globalstep(function(dtime)
    time2 = time2 + dtime

	-- every 1 second
	if time2 > 1 then

		-- reset time for next check
		time2 = 0

		-- check players
		for _,player in ipairs(minetest.get_connected_players()) do
			
			-- where am I?
			local pos = player:getpos()
				
			-- am I near a block of uranium?
			local near = minetest.find_node_near(pos, 1, "corruptionlands:rejuvestation")

			if near then
					
				-- am I touching the uranium? if so it hurts
				for _,object in ipairs(minetest.get_objects_inside_radius(near, 1.0)) do
                    object:set_hp(object:get_hp()+1)
				end

			end

		end
		
	end
end)

minetest.register_node("corruptionlands:gunmetal", {
    description = "Spraps of gunmetal.",
    tiles = {"gunmetal.png"},
    -- paramtype2 = "facedir",
    groups = {cracky = 3, level = 2},

    sounds = default.node_sound_glass_defaults()
})


-- Remains
minetest.register_node("corruptionlands:bones", {
    description = "Remains of humans as bones in a mass biome.",
    tiles = {"bones_top.png", "bones_bottom.png", "bones_side.png", "bones_front.png", "bones_rear.png"},
    paramtype2 = "facedir",
    groups = {crumbly = 3, level = 1},

    sounds = default.node_sound_dirt_defaults()
})

--minetest.register_abm({
--    nodenames = {"corruptionlands:bones"},
--
--    description = "Adaptation of natural cactus to resist corruption by radioactive slime.",
--
--	neighbors = {"default:dirt", "default:dirt_with_grass"},
--
--	interval = 30.0, -- Run every 10 seconds
--	chance = 3, -- Select every 1 in 10 nodes
--
--	action = function(pos, node, active_object_count, active_object_count_wider)
--		minetest.set_node({x = pos.x, y = pos.y + 1, z = pos.z + 1}, {name = "corruptionlands:bones"})
--	end
--})
--

-- Registers healing and damage blocks.
minetest.register_node("corruptionlands:rejuvestation", {
    description = "The anti-thesis of corruption blocks.",
    tiles = {"rejuvestation_top.png", "rejuvstation_bottom.png", "rejuvstation_right.png", "rejuvstation_left.png", "rejuvstation_front.png", "rejuvstation_back.png"},
    paramtype2 = "facedir",
    groups = {crumbly = 3, level = 3},

    sounds = default.node_sound_dirt_defaults()
})

minetest.register_abm({
    nodenames = {"corruptionlands:rejuvestation"},

    description = "Adaptation of natural cactus to resist corruption by radioactive slime.",

	neighbors = {"corruptionlands:infected"},

	interval = 30.0, -- Run every 10 seconds
	chance = 3, -- Select every 1 in 10 nodes

	action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.set_node({x = pos.x, y = pos.y + 1, z = pos.z + 1}, {name = "corruptionlands:rejuvestation"})
	end
})

minetest.register_node("corruptionlands:infected", {
    description = "Corrupts dirt, grass, stone, sandstone, and other blocks.",
    tiles = {"corruption_top.png", "corruption_bottom.png", "corruption_right.png", "corruption_left.png", "corruption_front.png", "corruption_back.png"},
    paramtype2 = "facedir",
    groups = {crumbly = 3},
    on_use = minetest.item_eat(3),

    sounds = default.node_sound_dirt_defaults()
})

minetest.register_abm({
	nodenames = {"corruptionlands:infected"},

	neighbors = {"default:dirt",  "default:dirt_with_grass", "defaukt:dirt_with_snow", "default:permafrost",
                 "default:sand", "default:gravel"},

	interval = 10.0, -- Run every 10 seconds
	chance = 3, -- Select every 1 in 10 nodes

	action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.set_node({x = pos.x, y = pos.y + 1, z = pos.z + 1}, {name = "corruptionlands:infected"})
	end
})

-- Creates a corruption and rejuvination biomes.
--minetest.register_biome({
--    name = "Burial Grounds One",
--
--    node_top = "corruptionlands:bones",
--    depth_top = 6,
--    node_filler = "default:dirt",
--    depth_filler = 15,
--    node_stone = "default:stone",
--  
--    -- Total Size
--    y_max = 5000, y_min = -2000,
--    --x_max = 1000, x_min = 100,
--
--    -- Vertical blending
--    -- vertical_blend = 10,
--
--    -- Heat and humidity
--    heat_point = 66,
--    humidity = 101,
--})

minetest.register_biome({
    name = "Burial Grounds Two",

    node_top = "corruptionlands:bones",
    depth_top = 6,
    node_filler = "default:dirt",
    depth_filler = 15,
    node_stone = "default:stone",
  
    -- Total Size
    y_max = 5000, y_min = -2000,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 37,
    humidity = 2,
})


minetest.register_biome({
    name = "Rejuvelandia",

    node_top = "corruptionlands:rejuvestation",
    depth_top = 6,
    node_filler = "default:sand",
    depth_filler = 15,
    node_stone = "default:sandstone",
  
    -- Total Size
    y_max = 5000, y_min = -2000,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 65,
    humidity = 2,
})

minetest.register_biome({
    name = "Snowy Badlands",

    node_top = "corruptionlands:infected",
    depth_top = 6,
    node_filler = "default:stone",
    depth_filler = 15,
    node_stone = "default:sand",
  
    -- Total Size
    y_max = 5000, y_min = -2000,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 36,
    humidity = 1,
})

minetest.register_biome({
    name = "Rainforest Badlands",

    node_top = "corruptionlands:infected",
    depth_top = 6,
    node_filler = "default:stone",
    depth_filler = 15,
    node_stone = "default:sand",
  
    -- Total Size
    y_max = 5000, y_min = -2000,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 95,
    humidity = 95,
})

minetest.register_biome({
    name = "Taiga Badlands",

    node_top = "corruptionlands:infected",
    depth_top = 6,
    node_filler = "default:stone",
    depth_filler = 15,
    node_stone = "default:sand",
  
    -- Total Size
    y_max = 5000, y_min = -2000,
    --x_max = 1000, x_min = 100,

    -- Vertical blending
    -- vertical_blend = 10,

    -- Heat and humidity
    heat_point = 1,
    humidity = 99,
})

-- Experimental ( Using infection boots as a shield, act similarly to an infected slab.)

minetest.register_node("corruptionlands:corruption_boots", {
    description = "Where your infection resistant boots go.",

    tiles = {"corruption_boots_top.png", "corruption_bottom.png", "corruption_right.png", "corruption_left.png", "corruption_front.png", "corruption_back.png"},

    paramtype2 = "facedir",
    groups = {oddly_breakable_by_hand = 2},
    sounds = default.node_sound_dirt_defaults()
})

-- Registers Crafts
minetest.register_craft({
  output = "corruptionlands:corruption_boots",
  recipe = {
    {"corruptionlands:infected", "woodclogs:first"},
  }
})
