local time1 = 0
local time2 = 0

minetest.register_node("extendedwool:green_river_water", {
	description = "Green River Water Source",
	drawtype = "liquid",
	tiles = {
		{
			name = "green_water_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "green_water_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "extendedwool:green_river_water_flowing",
	liquid_alternative_source = "extendedwool:green_river_water",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 2,
	post_effect_color = {a = 103, r = 30, g = 76, b = 90},
	groups = {water = 3, liquid = 3, cools_lava = 1},
    --groups = {lava = 1},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("extendedwool:green_river_water_flowing", {
	description = "Flowing Green River Water",
	drawtype = "flowingliquid",
	tiles = {"green_river_water.png"},
	special_tiles = {
		{
			name = "green_water_flowing_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.5,
			},
		},
		{
			name = "green_water_flowing_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.5,
			},
		},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "extendedwool:green_river_water_flowing",
	liquid_alternative_source = "extendedwool:green_river_water",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 2,
	post_effect_color = {a = 103, r = 30, g = 76, b = 90},
	groups = {water = 3, liquid = 3, not_in_creative_inventory = 1,
		cools_lava = 1},
    --groups = {lava = 1},

    on_use = minetest.item_eat(3),

	sounds = default.node_sound_water_defaults(),
})

minetest.register_abm({
	nodenames = {"extendedwool:green_river_water_flowing"},

	neighbors = {"default:sand", "default:silver_sand", "default:water_source"},

	interval = 3.0, -- Run every 10 seconds
	chance = 3, -- Select every 1 in 10 nodes

	action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.set_node({x = pos.x, y = pos.y + 1, z = pos.z + 1}, {name = "extendedwool:green_river_water_flowing"})
	end
})


--minetest.register_biome({
--    name = "Green river water biome.",
--
--    node_top = "extendedwool:green_river_water",
--    depth_top = 6,
--    node_filler = "default:dirt",
--    depth_filler = 15,
--    node_stone = "default:stone",
--  
--    -- Total Size
--    y_max = 5000, y_min = -2000,
--    --x_max = 1000, x_min = 100,
--
--    -- Vertical blending
--    -- vertical_blend = 10,
--
--    -- Heat and humidity
--    heat_point = 37,
--    humidity = 2,
--})

minetest.register_globalstep(function(dtime)
    time1 = time1 + dtime

	-- every 1 second
	if time1 > 1 then

		-- reset time for next check
		time1 = 0

		-- check players
		for _,player in ipairs(minetest.get_connected_players()) do
			
			-- where am I?
			local pos = player:getpos()
				
			-- am I near a block of uranium?
			local near = minetest.find_node_near(pos, 1, "extendedwool:green_river_water")

			if near then
					
				-- am I touching the uranium? if so it hurts
				for _,object in ipairs(minetest.get_objects_inside_radius(near, 1.0)) do
                    object:set_hp(object:get_hp()+4)
				end

			end

		end
		
	end
end)

minetest.register_globalstep(function(dtime)
    time2 = time2 + dtime

	-- every 1 second
	if time2 > 1 then

		-- reset time for next check
		time2 = 0

		-- check players
		for _,player in ipairs(minetest.get_connected_players()) do
			
			-- where am I?
			local pos = player:getpos()
				
			-- am I near a block of uranium?
			local near = minetest.find_node_near(pos, 1, "extendedwool:green_river_water_flowing")

			if near then
					
				-- am I touching the uranium? if so it hurts
				for _,object in ipairs(minetest.get_objects_inside_radius(near, 1.0)) do
                    object:set_hp(object:get_hp()+4)
				end

			end

		end
		
	end
end)

-- Green Water Bucket
--minetest.register_tool("extendedwool:green_bucket", {
--	description = "Bucket of green water.",
--	inventory_image = "bucket_green_water.png",
--	tool_capabilities = {
--		full_punch_interval = 0.9,
--		max_drop_level=3,
--		groupcaps={
--			cracky = {times={[1]=1.0, [2]=0.5, [3]=0.25}, uses=30, maxlevel=4},
--		},
--		damage_groups = {fleshy=330},
--	},
--	sound = {breaks = "default_tool_breaks"},
--	groups = {pickaxe = 1}
--})

--minetest.register_craftitem("extendedwool:green_bucket", {
--    description = "Bucket of green water.",
--    inventory_image = "bucket_green_water.png",
--})
--
--minetest.register_craft({
--  output = "extendedwool:green_bucket",
--  recipe = {
--    {"dye:dark_green", "dye:dark_grey", "bucket:bucket_water"},
--  }
--})

-- Wool Blocks
minetest.register_node("extendedwool:mineral_green", {
    description = "Sheep wool dyed mineral green.",
    tiles = {"wool_mineralgreen.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("extendedwool:tosca", {
    description = "Sheep wool dyed tosca red.",
    tiles = {"wool_tosca.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("extendedwool:barossa", {
    description = "Sheep wool dyed barossa purple.",
    tiles = {"wool_barossa.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

-- Types of black wool
minetest.register_node("extendedwool:night_rider", {
    description = "Sheep wool dyed night rider black.",
    tiles = {"wool_nightrider.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("extendedwool:black_pearl", {
    description = "Sheep wool dyed black pearl.",
    tiles = {"wool_blackpearl.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("extendedwool:bunker", {
    description = "Sheep wool dyed bunker grey.",
    tiles = {"wool_bunker.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("extendedwool:vulcan", {
    description = "Sheep wool dyed vulcan grey.",
    tiles = {"wool_bunker.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_dirt_defaults(),
})

-- Bricks
minetest.register_node("extendedwool:mineral_green_bricks", {
    description = "Dark grey green bricks.",
    tiles = {"mineral_green_brick.png"},
    --paramtype2 = "facedir",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},
	sounds = default.node_sound_stone_defaults(),
})

-- Bucket
minetest.register_craftitem("extendedwool:green_bucket", {
    description = "Bucket of green water.",
    inventory_image = "bucket_green_water.png",
})

--minetest.register_alias("bucket_green_water", "extendedwool:green_bucket")

--bucket.register_liquid("extendedwool:green_river_water", "extendedwool:green_river_water_flowing", "extendedwool:green_bucket", "bucket_green_water.png")

minetest.register_craftitem("extendedwool:green_bucket", {
    description = "Bucket of green water.",
    inventory_image = "bucket_green_water.png",
    stack_max = 1,
    liquids_pointable = true,

--    on_use = function(itemstack, user, pointed_thing)
--        local node = minetest.get_node(pointed_thing.under)
--        if node.name == "air" then
--            minetest.set_node(pointed_thing.under, {name = "extendedwool:green_river_water"})
--            return ItemStack("bucket:bucket_empty")
--        elseif node.name == "extendedwool:green_river_water" then
--            minetest.set_node(pointed_thing.under, {name = "air"})
--            return itemstack
--        end
--        return itemstack
--    end,
})

-- Define the recipe
minetest.register_craft({
    output = "extendedwool:green_bucket",
    recipe = {
        {"dye:dark_green", "dye:dark_grey", "bucket:bucket_water"},
    }
})

minetest.register_craft({
  output = "extendedwool:mineral_green",
  recipe = {
    {"extendedwool:green_bucket", "wool:white"},
  }
})
