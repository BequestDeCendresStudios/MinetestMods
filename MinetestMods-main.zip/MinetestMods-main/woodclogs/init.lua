-- First Block Test
minetest.register_node("woodclogs:first", {

    description  = "Alien Block",

    tiles = {"alien_block.png"},

    groups = {cracky = 3, level = 3},

    --on_use = minetest.item_eat(1),

    sounds = default.node_sound_glass_defaults()
})

--minetest.register_abm({
--    nodenames = {"woodclogs:first"},
--
--    description = "Nuetralizes Infected and Rejuvination blocks.",
--
--	neighbors = {"corruptionlands:infected", "corruptionlands:rejuvestation"},
--
--	interval = 3.0, -- Run every 10 seconds
--	chance = 3, -- Select every 1 in 10 nodes
--
--	action = function(pos, node, active_object_count, active_object_count_wider)
--		minetest.set_node({x = pos.x, y = pos.y + 1, z = pos.z + 1}, {name = "woodclogs:first"})
--	end
--})



--minetest.register_craft({
    --output = "woodclogs:first",
    --recipe = {{"default:dirt", "default:dirt"}},
--})

-- Second Block Test
minetest.register_node("woodclogs:clogs", {

    description  = "Odd Block",
    tiles = {"uncanny_wood.png"},
    groups = {oddly_breakable_by_hand = 2},
    sounds = default.node_sound_wood_defaults()

})

--minetest.register_craft({
    --output = "woodclogs:clogs",
    --recipe = {{"default:wool", "default:wool"}},
--})
minetest.register_tool("woodclogs:alienpick", {
	description = "Alien Pickaxe",
	inventory_image = "alien_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=1.0, [2]=0.5, [3]=0.25}, uses=30, maxlevel=4},
		},
		damage_groups = {fleshy=330},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("woodclogs:alienshovel", {
    description = "Alien Shovel",
    inventory_image = "alienglass_shovel.png",
    tool_capabilities = {
        full_punch_interval = 0.9,
        mas_drop_leve=3,
        groupcaps={
            crumbly = {times={[1]=1.0, [2]=0.5, [3]=0.25}, uses=30, maxlevel=4},
        },
        damage_groups = {flesh=330}
    },
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1}
})

-- Stone Blocks
minetest.register_node("woodclogs:purplestone", {

   description = "Purple Stone",
   tiles = {"purple_stone.png"},
   groups = {cracky = 2},
   sounds = default.node_sound_stone_defaults()

})

minetest.register_node("woodclogs:orangestone", {

   description = "Orange Stone",
   tiles = {"orange_stone.png"},
   groups = {cracky = 2},
   sounds = default.node_sound_stone_defaults()

})

minetest.register_node("woodclogs:coffeestone", {

   description = "Coffee Stone",
   tiles = {"coffee_stone.png"},
   groups = {cracky = 2},
   sounds = default.node_sound_stone_defaults()

})

-- Wood Blocks

minetest.register_node("woodclogs:purple", {

   description = "Purple Wood",
   tiles = {"purple_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

minetest.register_node("woodclogs:orange", {

   description = "Orange Wood",
   tiles = {"orange_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

minetest.register_node("woodclogs:coffee", {

   description = "Coffee Wood",
   tiles = {"coffee_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

minetest.register_node("woodclogs:dark", {

   description = "Dark Wood",
   tiles = {"dark_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})


-- Homemade Ink Colored Blocks

-- -- Tosca
minetest.register_node("woodclogs:tosca", {

   description = "Tosca Wood",
   tiles = {"tosca_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

-- -- Barossa
minetest.register_node("woodclogs:barossa", {

   description = "Barossa Wood",
   tiles = {"barossa_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

-- -- Gunmetal
minetest.register_node("woodclogs:gunmetal", {

   description = "Gunmetal Wood",
   tiles = {"gunmetal_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

-- -- Empress
minetest.register_node("woodclogs:empress", {

   description = "Empress Wood",
   tiles = {"empress_wood.png"},
   groups = {oddly_breakable_by_hand = 2},
   sounds = default.node_sound_wood_defaults()

})

-- Registering biomes, such as where to find Alien Glass.
--minetest.register_biome({
--    name = "Crash Landing Zone One",
--
--    node_top = "woodclogs:first",
--    depth_top = 6,
--    node_filler = "default:sand",
--    depth_filler = 15,
--    node_stone = "default:sandstone",
--  
--    -- Total Size
--    y_max = 1300, y_min = -2000,
--    --x_max = 1000, x_min = 100,
--
--    -- Vertical blending
--    -- vertical_blend = 10,
--
--    -- Heat and humidity
--    heat_point = 99,
--    humidity = 1,
--})

-- Registering biomes, such as where to find Alien Glass.
--minetest.register_biome({
--    name = "Crash Landing Zone Two",
--
--    node_top = "woodclogs:first",
--    depth_top = 6,
--    node_filler = "default:sand",
--    depth_filler = 15,
--    node_stone = "default:sandstone",
--  
--    -- Total Size
--    y_max = 12000, y_min = 5000,
--    --x_max = 1000, x_min = 100,
--
--    -- Vertical blending
--    -- vertical_blend = 10,
--
--    -- Heat and humidity
--    heat_point = 64,
--    humidity = 1,
--})


-- Ores
minetest.register_ore({
	ore_type        = "blob",
	ore             = "woodclogs:first",
	wherein         = {"default:dirt", "default:dirt_with_grass", "default:stone"},
	clust_scarcity  = 16 * 16 * 16,
	clust_size      = 7,
	y_max           = 100,
	y_min           = 0,
	noise_threshold = 0.0,
	noise_params    = {
		offset = 0.5,
		scale = 0.2,
		spread = {x = 5, y = 5, z = 5},
		seed = 2316,
		octaves = 1,
		persist = 0.0
	},
})

-- Decorations
--	minetest.register_decoration({
--		name = "default:apple_log",
--		deco_type = "schematic",
--		place_on = {"default:dirt_with_grass"},
--		place_offset_y = 1,
--		sidelen = 16,
--		noise_params = {
--			offset = 0.0012,
--			scale = 0.0007,
--			spread = {x = 250, y = 250, z = 250},
--			seed = 2,
--			octaves = 3,
--			persist = 0.66
--		},
--		biomes = {"deciduous_forest"},
--		y_max = 31000,
--		y_min = 1,
--		schematic = minetest.get_modpath("default") .. "/schematics/apple_log.mts",
--		flags = "place_center_x",
--		rotation = "random",
--		spawn_by = "default:dirt_with_grass",
--		num_spawn_by = 8,
--	})

