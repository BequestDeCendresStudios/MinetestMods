local time1 = 0

minetest.register_globalstep(function(dtime)
    time1 = time1 + dtime

	-- every 1 second
	if time1 > 1 then

		-- reset time for next check
		time1 = 0

		-- check players
		for _,player in ipairs(minetest.get_connected_players()) do
			
			-- where am I?
			local pos = player:getpos()
				
			-- am I near a block of uranium?
			local near = minetest.find_node_near(pos, 1, "widow:neckhole_back")

			if near then
					
				-- am I touching the uranium? if so it hurts
				for _,object in ipairs(minetest.get_objects_inside_radius(near, 1.0)) do
                    object:set_hp(object:get_hp()-20)
				end

			end

		end
		
	end
end)

minetest.register_node("widow:blade_front", {
    description = "Razor blade for decapitation.",
    --tiles = {"guillotine_top.png", "beds_transparent.png", "guillotine_right.png", "guillotine_left.png", "blade_front.png", "beds_transparent.png"},
    tiles = {"guillotine_top.png", "beds_transparent.png", "guillotine_left.png", "guillotine_right.png", "beds_transparent.png", "blade_back.png^[transformFX"},

    drawtype = "nodebox",

    paramtype2 = "facedir",

    walkable = true,
    is_ground_content = true,

    --liquidtype = "source",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},

	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("widow:blade", {
    description = "Razor blade for decapitation.",
    --tiles = {"guillotine_top.png", "beds_transparent.png", "guillotine_right.png", "guillotine_left.png", "blade_front.png", "beds_transparent.png"},
    tiles = {"guillotine_top.png", "beds_transparent.png", "beds_transparent.png", "beds_transparent.png", "beds_transparent.png", "blade_front.png^[transformFX"},

    drawtype = "nodebox",

    paramtype2 = "facedir",

    walkable = true,
    is_ground_content = true,

    --liquidtype = "source",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},

	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("widow:posts_front", {
    description = "Posts for holding up blade for decapitation.",
    tiles = {"beds_transparent.png", "beds_transparent.png", "guillotine_right.png", "guillotine_left.png", "guillotine_height.png", "beds_transparent.png"},

    drawtype = "nodebox",

    paramtype2 = "facedir",

    walkable = true,
    is_ground_content = true,

    --liquidtype = "source",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},

	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("widow:posts_back", {
    description = "Posts for holding up blade for decapitation.",
    tiles = {"beds_transparent.png", "beds_transparent.png", "beds_transparent.png", "beds_transparent.png", "guillotine_height.png", "beds_transparent.png"},

    drawtype = "nodebox",

    paramtype2 = "facedir",

    walkable = true,
    is_ground_content = true,

    --liquidtype = "source",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},

	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("widow:neckhole_back", {
    description = "Hole for placing victim's neck.",
    tiles = {"beds_transparent.png", "beds_transparent.png", "guillotine_right.png", "guillotine_left.png", "guillotine_stock.png", "beds_transparent.png"},

    drawtype = "nodebox",

    paramtype2 = "facedir",

    walkable = true,
    is_ground_content = true,

    --liquidtype = "source",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},

	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("widow:neckhole_front", {
    description = "Hole for placing victim's neck.",
    tiles = {"beds_transparent.png", "beds_transparent.png", "beds_transparent.png", "beds_transparent.png", "guillotine_stock.png", "beds_transparent.png"},

    drawtype = "nodebox",

    paramtype2 = "facedir",

    walkable = true,
    is_ground_content = true,

    --liquidtype = "source",

	--is_ground_content = false,
	groups = {snappy = 2, choppy = 2, oddly_breakable_by_hand = 3,
	flammable = 3, wool = 1},

	sounds = default.node_sound_wood_defaults(),
})
