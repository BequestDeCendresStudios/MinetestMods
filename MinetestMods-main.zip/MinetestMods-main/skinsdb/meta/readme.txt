For each skin in textures folder a metadata file can be applied with "txt" suffilx. See character.txt for skin character.png for reference.
The file contains:
Skin name
Author
License
